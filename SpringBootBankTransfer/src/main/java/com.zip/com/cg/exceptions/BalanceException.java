package com.cg.exceptions;

public class BalanceException extends Exception{

	public BalanceException() {
		super();
	}

	public BalanceException(String message) {
		super(message);
	}
	

}
